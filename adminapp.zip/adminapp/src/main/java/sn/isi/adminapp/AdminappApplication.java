package sn.isi.adminapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdminappApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdminappApplication.class, args);
	}

}
